import {Component, OnInit, ViewContainerRef} from '@angular/core';
import {Response} from '@angular/http';
import {Helper} from "../../helper";
declare var jQuery: any;
import * as moment from 'moment-timezone';
@Component({
    selector: 'app-orders',
    templateUrl: './orders.component.html',
    providers: [Helper]
})
export class OrdersComponent implements OnInit {

    title: any;
    button: any;
    ORDER_STATE: any;
    DATE_FORMAT: any;
    heading_title: any;
    status: any;
    lable_title: any;

    order_list: any[];
    interval: any;

    sort_field: string;
    sort_order: number;
    search_field: string;
    search_value: string;
    page: number;
    total_page: number;
    total_pages: number[];
    myLoading: boolean = true;
    moment: any;
    timezone: string;

    constructor(private helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);
    }
    ngAfterViewInit() {

        jQuery(".chosen-select").chosen({disable_search: true});
        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);


    }

    ngOnInit() {


        this.sort_field = "unique_id";
        this.sort_order = -1;
        this.search_field = "user_detail.first_name";
        this.search_value = "";
        this.page = 1;
        this.moment = moment;
        this.timezone = "";




        this.helper.message()


        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.ORDER_STATE = this.helper.ORDER_STATE
        this.DATE_FORMAT = this.helper.DATE_FORMAT
        this.status = this.helper.status
        this.lable_title = this.helper.lable_title
        this.order_list = [];

        this.orderDetail()
        this.interval = setInterval(() => {
            this.orderDetail()
        }, this.helper.TIMEOUT.NEW_ORDER_REQUEST);

        this.filter(1);




        jQuery(this.helper.elementRef.nativeElement).find('#sort_field').on('change', (evnt, res_data) => {

            this.sort_field = res_data.selected;

        });
        jQuery(this.helper.elementRef.nativeElement).find('#sort_order').on('change', (evnt, res_data) => {

            this.sort_order = res_data.selected;

        });
        jQuery(this.helper.elementRef.nativeElement).find('#search_field').on('change', (evnt, res_data) => {

            this.search_field = res_data.selected;

        });
    }

    ngOnDestroy() {
        clearInterval(this.interval);
    }
    activeRoute(routename: string): boolean {
        return this.helper.router.url.indexOf(routename) > -1;
    }

    filter(page) {
        this.page = page;
        this.helper.http.post('/api/admin/order_lists_search_sort', {
            sort_field: this.sort_field, sort_order: this.sort_order,
            search_field: this.search_field, search_value: this.search_value, page: this.page
        }).map((res: Response) => res.json()).subscribe(res_data => {
            this.myLoading = false;
            if (res_data.success == false) {


                this.order_list = [];
                this.total_pages = [];

            }
            else {
                this.timezone = res_data.timezone;
                this.order_list = res_data.orders;
                this.total_page = res_data.pages;
                this.total_pages = Array(res_data.pages).fill((x, i) => i).map((x, i) => i + 1)
            }
        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });
    }

    vieworder_detail(id) {
        this.helper.router_id.admin.order_id = id;
        this.helper.router.navigate(['admin/order_detail']);
    }


    orderDetail() {
        this.helper.http.post('/api/admin/order_lists_search_sort', {

            sort_field: this.sort_field, sort_order: this.sort_order,
            search_field: this.search_field, search_value: this.search_value, page: this.page
        }).map((res: Response) => res.json()).subscribe(res_data => {

            this.myLoading = false;
            if (res_data.success == false) {
                this.order_list = [];
                this.total_page = res_data.pages;
                this.total_pages = Array(res_data.pages).fill((x, i) => i).map((x, i) => i + 1)
            }
            else {
                this.timezone = res_data.timezone;
                this.total_page = res_data.pages;
                this.total_pages = Array(res_data.pages).fill((x, i) => i).map((x, i) => i + 1)

                this.order_list.forEach((value, index) => {

                    var new_index = res_data.orders.findIndex(x => x._id == this.order_list[index]._id)
                    if (new_index == -1) {
                        this.order_list.splice(index, 1)
                    }
                    else {
                        this.order_list[index].order_status = res_data.orders[new_index].order_status;
                        //this.order_list[index].provider_detail = res_data.orders[new_index].provider_detail;
                    }
                });

                res_data.orders.forEach((new_value, index) => {
                    var aaa = this.order_list.findIndex(x => x._id == res_data.orders[index]._id)

                    if (aaa == -1) {
                        this.order_list.push(new_value)
                    }

                });
            }
        },
            (error: any) => {
                this.helper.http_status(error)
            });
    }




    today_order_export_csv() {
        this.helper.http.post('/api/admin/order_lists_search_sort', {

            sort_field: this.sort_field, sort_order: this.sort_order,
            search_field: this.search_field, search_value: this.search_value, page: this.page
        }).map((res: Response) => res.json()).subscribe(res_data => {
            var length = 0;
            if (res_data.orders.length > 0) {
                var json2csv = require('json2csv');
                res_data.orders.forEach((order, index) => {
                    if (order.order_payment_detail.is_paid_from_wallet) {
                        order.payment_status = this.title.wallet;
                    } else {
                        if (order.order_payment_detail.is_payment_mode_cash) {
                            order.payment_status = this.lable_title.cash;
                        } else {
                            if (order.order_payment_detail.length > 0) {
                                order.payment_status = order.payment_gateway_detail[0].name;
                            }
                        }
                    }

                    order.user_name = order.user_detail.first_name + ' ' + order.user_detail.last_name;
                    order.store_name = order.store_detail.name;

                    order.city_name = order.city_detail.city_name;


                    switch (order.order_status) {
                        case this.ORDER_STATE.WAITING_FOR_ACCEPT_STORE:
                            order.status = this.status.waiting_for_accept;
                            break;
                        case this.ORDER_STATE.STORE_ACCEPTED:
                            order.status = this.status.accepted;
                            break;
                        case this.ORDER_STATE.STORE_PREPARING_ORDER:
                            order.status = this.status.start_preparing_order;
                            break;
                        case this.ORDER_STATE.OREDER_READY:
                            order.status = this.status.order_ready;
                            break;

                        case this.ORDER_STATE.ORDER_COMPLETED:
                            order.status = this.status.completed;
                            break;
                        case this.ORDER_STATE.STORE_CANCELLED_REQUEST:
                            order.status = this.status.store_cancelled_request;
                            break;
                        case this.ORDER_STATE.NO_DELIVERY_MAN_FOUND:
                            order.status = this.status.no_delivery_man_found;
                            break;

                        case this.ORDER_STATE.STORE_REJECTED:
                            order.status = this.status.rejected;
                            break;
                        case this.ORDER_STATE.STORE_CANCELLED:
                            order.status = this.status.cancelled;
                            break;
                        case this.ORDER_STATE.DELIVERY_MAN_REJECTED:
                            order.status = this.status.delivery_man_rejected;
                            break;
                        case this.ORDER_STATE.DELIVERY_MAN_CANCELLED:
                            order.status = this.status.delivery_man_cancelled;
                            break;
                        case this.ORDER_STATE.CANCELED_BY_USER:
                            order.status = this.status.user_cancelled;
                            break;




                        default:
                            order.satus = '';
                    }
                    order.amount = ((+order.order_payment_detail.total_delivery_price + +order.order_payment_detail.total_order_price).toFixed(2));
                });
            }

            var fieldNames = [this.title.id,
            this.title.user,
            this.title.store,
            this.title.city,
            this.title.status,
            this.title.amount,
            this.title.payment_by,
            this.title.date,
            this.title.delivery_at
            ];
            var fields = ['unique_id',
                'user_name',
                'store_name',
                'city_name',
                'status',
                'amount',
                'payment_status',
                'created_at',
                'delivered_at'
            ];


            var csv = json2csv({data: res_data.orders, fields: fields, fieldNames: fieldNames});

            var final_csv: any = csv;
            this.helper.downloadFile(final_csv);
        });
    }



    today_order_export_excel() {
        this.helper.http.post('/api/admin/order_lists_search_sort', {

            sort_field: this.sort_field, sort_order: this.sort_order,
            search_field: this.search_field, search_value: this.search_value, page: this.page
        }).map((res: Response) => res.json()).subscribe(res_data => {
            var length = 0;

            var json_data = [];
            var json2excel = require('js2excel');
            if (res_data.orders.length > 0) {
             res_data.orders.forEach((order, index) => {
                    if (order.order_payment_detail.is_paid_from_wallet) {
                        order.payment_status = this.title.wallet;
                    } else {
                        if (order.order_payment_detail.is_payment_mode_cash) {
                            order.payment_status = this.lable_title.cash;
                        } else {
                            if (order.order_payment_detail.length > 0) {
                                order.payment_status = order.payment_gateway_detail[0].name;
                            }
                        }
                    }

                    order.user_name = order.user_detail.first_name + ' ' + order.user_detail.last_name;
                    order.store_name = order.store_detail.name;

                    order.city_name = order.city_detail.city_name;


                    switch (order.order_status) {
                        case this.ORDER_STATE.WAITING_FOR_ACCEPT_STORE:
                            order.status = this.status.waiting_for_accept;
                            break;
                        case this.ORDER_STATE.STORE_ACCEPTED:
                            order.status = this.status.accepted;
                            break;
                        case this.ORDER_STATE.STORE_PREPARING_ORDER:
                            order.status = this.status.start_preparing_order;
                            break;
                        case this.ORDER_STATE.OREDER_READY:
                            order.status = this.status.order_ready;
                            break;

                        case this.ORDER_STATE.ORDER_COMPLETED:
                            order.status = this.status.completed;
                            break;
                        case this.ORDER_STATE.STORE_CANCELLED_REQUEST:
                            order.status = this.status.store_cancelled_request;
                            break;
                        case this.ORDER_STATE.NO_DELIVERY_MAN_FOUND:
                            order.status = this.status.no_delivery_man_found;
                            break;

                        case this.ORDER_STATE.STORE_REJECTED:
                            order.status = this.status.rejected;
                            break;
                        case this.ORDER_STATE.STORE_CANCELLED:
                            order.status = this.status.cancelled;
                            break;
                        case this.ORDER_STATE.DELIVERY_MAN_REJECTED:
                            order.status = this.status.delivery_man_rejected;
                            break;
                        case this.ORDER_STATE.DELIVERY_MAN_CANCELLED:
                            order.status = this.status.delivery_man_cancelled;
                            break;
                        case this.ORDER_STATE.CANCELED_BY_USER:
                            order.status = this.status.user_cancelled;
                            break;




                        default:
                            order.satus = '';
                    }
                    order.amount = ((+order.order_payment_detail.total_delivery_price + +order.order_payment_detail.total_order_price).toFixed(2));
                json_data.push({
                    "ID": order.unique_id,
                    "User":order.user_name,
                    "Store":order.store_name,
                    "City":order.city_name,
                    "Status":order.status,
                    "Amount":order.amount,
                    "Payment By": order.payment_status,
                    "Date":order.created_at
                    
                 });
                
                
                });
        }

            json2excel.json2excel({
                data: json_data,
                name: 'today_order_excel',
                formateDate: 'yyyy/mm/dd'
            });

        });
    }




}
