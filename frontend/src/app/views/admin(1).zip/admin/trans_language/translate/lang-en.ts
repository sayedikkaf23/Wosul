// lang-en.ts

export const LANG_EN_NAME = 'en';

export const LANG_EN_TRANS = {
    'hello world': 'hello world',
    'hi': 'hi',
    'dashboard':'dashboard'
};