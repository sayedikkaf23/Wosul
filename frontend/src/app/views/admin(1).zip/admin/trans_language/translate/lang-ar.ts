// lang-ar.ts

export const LANG_AR_NAME = 'ar';

export const LANG_AR_TRANS = {
    'hello world': 'مرحبا بالعالم',
    'hi':'مرحبا',
    'dashboard':'لوحة القيادة'
};