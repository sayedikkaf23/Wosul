// lang-es.ts

export const LANG_ES_NAME = 'es';

export const LANG_ES_TRANS = {
    'hello world': 'hola mundo',
    'hi':'Hola',
    'dashboard':'tablero'
};