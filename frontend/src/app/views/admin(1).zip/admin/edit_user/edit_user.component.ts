import {Component, OnInit, ViewContainerRef} from '@angular/core';
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Helper} from "../../helper";
declare var jQuery: any;

export interface UserEdit {

    user_id: Object,
    first_name: String,
    last_name: String,
    email: String,
    //zipcode: String,
    //old_password: String,
    //new_password: String,
    country_name: String,
    city_name: String,
    city: String,
    address: String,
    country_phone_code: String,
    phone: Number,
    image_url: String,
    
     _id: Object,
    unique_id:Number,

    provider_rate: Number,
    device_type: String,
    is_use_wallet: Boolean,
    is_document_uploaded: Boolean,

    referral_code: String,
    wallet: Number,
    referred_by: Object,
    total_referrals: Number,
    referred_user_first_name: String,
    referred_user_last_name: String,
    wallet_currency_code: String,
    app_version: String,
    comments: String,

    is_approved: Boolean,
    is_email_verified: Boolean,
    is_phone_number_verified: Boolean,
    //is_document_uploaded: Boolean,
    is_user_type_approved: Boolean




}

@Component({
    selector: 'app-edit_user',
    templateUrl: './edit_user.component.html',
    providers: [Helper]
})
export class EditUserComponent implements OnInit {

    private user_edit: UserEdit;
    title: any;
    button: any;
    heading_title: any;
    //phone_number_length: number;
    minimum_phone_number_length: number;
    maximum_phone_number_length: number;
    user: any;
    user_id: Object;
    edit: Boolean;
    myLoading: boolean = true;
    //user_page_type: number;

    constructor(public helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);

    }

    ngOnInit() {
        this.user_edit = {
            user_id: "",
            first_name: "",
            last_name: "",
            email: "",
            
             _id: "",
            unique_id: null,
            
            //zipcode: "",
            country_name: "",
            city_name: "",
            city: "",
            address: "",
            country_phone_code: "",
            total_referrals: null,
            referred_user_first_name: "",
            referred_user_last_name: "",
            phone: null,
            image_url: "",
            referral_code: "",
            wallet: null,
            referred_by: "",
            wallet_currency_code: "",
            app_version: "",
            comments: "",
            is_approved: false,
            is_email_verified: false,
            is_phone_number_verified: false,

            provider_rate: null,
            device_type: "",
            is_use_wallet: false,
            is_document_uploaded: false,

            //is_document_uploaded: false,
            is_user_type_approved: false

        }
        this.user_id = this.helper.router_id.admin.user_id;
        var user = JSON.parse(localStorage.getItem('user'));
        
//        console.log(this.helper.route.snapshot.url[1]);
//        if (this.helper.route.snapshot.url[1].path == 'users') {
//            this.user_page_type = 1;
//        }
//        else if (this.helper.route.snapshot.url[1].path == 'declined_user') {
//            this.user_page_type = 2;
//        }



        this.helper.http.post('/admin/get_user_detail', {user_id: this.user_id}).map((response: Response) => response.json()).subscribe(res_data => {
            this.myLoading = false;
            if (res_data.success == false) {
                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
            }
            else {
                this.user_edit.first_name = res_data.user.first_name;
                this.user_edit.last_name = res_data.user.last_name;
                this.user_edit.email = res_data.user.email;
                
                this.user_edit._id = res_data.user._id;
                this.user_edit.unique_id = res_data.user.unique_id;
                
                //this.user_edit.zipcode = res_data.user.zipcode;
                this.minimum_phone_number_length = res_data.user.country_details.minimum_phone_number_length;
                this.maximum_phone_number_length = res_data.user.country_details.maximum_phone_number_length;

                this.user_edit.country_name = res_data.user.country_details.country_name;
                //this.user_edit.city_name = res_data.user.city_details.city_name;
                this.user_edit.address = res_data.user.address;
                this.user_edit.city = res_data.user.city;
                this.user_edit.country_phone_code = res_data.user.country_phone_code;
                this.user_edit.phone = res_data.user.phone;
                this.user_edit.image_url = res_data.user.image_url;
                
                this.user_edit.provider_rate = res_data.user.provider_rate;
                this.user_edit.device_type = res_data.user.device_type;
                this.user_edit.is_use_wallet = res_data.user.is_use_wallet;
                this.user_edit.is_document_uploaded = res_data.user.is_document_uploaded;
                


                this.user_edit.referral_code = res_data.user.referral_code;
                this.user_edit.wallet = res_data.user.wallet;

                this.user_edit.total_referrals = res_data.user.total_referrals;

                if (res_data.user.referred_user_details.length > 0) {
                    this.user_edit.referred_user_first_name = res_data.user.referred_user_details[0].first_name;
                    this.user_edit.referred_user_first_name = res_data.user.referred_user_details[0].last_name;
                }




                this.user_edit.referred_by = res_data.user.referred_by;
                this.user_edit.wallet_currency_code = res_data.user.wallet_currency_code;
                this.user_edit.app_version = res_data.user.app_version;
                this.user_edit.comments = res_data.user.comments;
                this.user_edit.is_approved = res_data.user.is_approved;
                this.user_edit.is_email_verified = res_data.user.is_email_verified;

                this.user_edit.is_phone_number_verified = res_data.user.is_phone_number_verified;
                //this.user_edit.is_document_uploaded = res_data.user.is_document_uploaded;
                this.user_edit.is_user_type_approved = res_data.user.is_user_type_approved;




            }


        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.edit = false;
    }
    public formData = new FormData();
    change_image($event) {

        const files = $event.target.files || $event.srcElement.files;
        const image_url = files[0];

        if (image_url.type == "image/jpeg" || image_url.type == "image/jpg" || image_url.type == "image/png") {
            this.formData = new FormData();
            this.formData.append('image_url', image_url);

            var reader = new FileReader();

            reader.onload = (e: any) => {
                this.user_edit.image_url = e.target.result
            }
            reader.readAsDataURL(image_url);
        }
    }
    //    change_image($event) {
    //        this.formData = new FormData();
    //        const files = $event.target.files || $event.srcElement.files;
    //        const image_url = files[0];
    //        this.formData.append('image_url', image_url);
    //
    //        var reader = new FileReader();
    //
    //        reader.onload = (e: any) => {
    //            this.user_edit.image_url = e.target.result
    //        }
    //        reader.readAsDataURL(image_url);
    //    }
    UpdateUser(user_data) {
        
        this.formData.append('user_id', user_data.user_id);

        this.formData.append('phone', user_data.phone);
        this.formData.append('email', user_data.email);
        this.formData.append('first_name', user_data.first_name);
        this.formData.append('last_name', user_data.last_name);
        this.formData.append('address', user_data.address);
        //this.formData.append('zipcode', user_data.zipcode);


        // this.formData.append('referral_code', user_data.referral_code);
        //this.formData.append('wallet', user_data.wallet);
        //this.formData.append('referred_by', user_data.referred_by);
        //this.formData.append('wallet_currency_code', user_data.wallet_currency_code);
        // this.formData.append('app_version', user_data.app_version);
        this.formData.append('comments', user_data.comments);
        this.formData.append('is_approved', user_data.is_approved);
        this.formData.append('is_email_verified', user_data.is_email_verified);
        this.formData.append('is_phone_number_verified', user_data.is_phone_number_verified);
        //this.formData.append('is_document_uploaded', user_data.is_document_uploaded);
        this.formData.append('is_user_type_approved', user_data.is_user_type_approved);


        this.helper.http.post('/admin/update_user', this.formData).map((response: Response) => response.json()).subscribe(res_data => {

            this.myLoading = false;
            jQuery('#remove').click();
            if (res_data.success == false) {

                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
                this.helper.message();
                this.formData = new FormData();
                this.user_edit.first_name = this.user.first_name;
                this.user_edit.last_name = this.user.last_name;
                //this.user_edit.zipcode = this.user.zipcode;
                this.user_edit.address = this.user.address;
                this.user_edit.phone = this.user.phone;
                this.user_edit.email = this.user.email;
                this.user_edit.image_url = this.user.image_url;

                // this.user_edit.referral_code = this.user.referral_code;
                // this.user_edit.wallet = this.user.wallet;
                // this.user_edit.referred_by = this.user.referred_by;
                // this.user_edit.wallet_currency_code = this.user.wallet_currency_code;
                // this.user_edit.app_version = this.user.app_version;
                this.user_edit.comments = this.user.comments;
                this.user_edit.is_approved = this.user.is_approved;
                this.user_edit.is_email_verified = this.user.is_email_verified;
                this.user_edit.is_phone_number_verified = this.user.is_phone_number_verified;
                //this.user_edit.is_document_uploaded = this.user.is_document_uploaded;
                this.user_edit.is_user_type_approved = this.user.is_user_type_approved;





            }
            else {
                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
                localStorage.setItem('user', JSON.stringify(res_data.user));
                
                this.helper.router.navigate(['admin/users']);
                
//                 if (user_page_type == 1) {
//                    this.helper.data.storage = {
//                        "message": this.helper.MESSAGE_CODE[res_data.message],
//                        "class": "alert-info"
//                    }
//                    this.helper.router.navigate(['admin/users']);
//                }
//                else if (user_page_type == 2) {
//                    this.helper.data.storage = {
//                        "message": this.helper.MESSAGE_CODE[res_data.message],
//                        "class": "alert-info"
//                    }
//
//                    this.helper.router.navigate(['admin/declined_user']);
//                }
            }
        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });

    }

}
