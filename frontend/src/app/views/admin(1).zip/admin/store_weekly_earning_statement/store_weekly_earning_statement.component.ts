import {Component, ViewContainerRef, Injectable, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Headers, Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Helper} from "../../helper";
declare var jQuery: any;
import 'rxjs/add/operator/toPromise';

//import * as jsPDF from 'jspdf'
declare let jsPDF;

export interface StoreAnalyticWeekly {
    received: number,
    accepted: number,
    rejected: number,
    cancelled: number,
    order_ready: number,
    completed: number,
    acception_ratio: number,
    rejection_ratio: number,
    cancellation_ratio: number,
    completed_ratio: number,
    total_items: number

}
export interface OrderTotal {
    pay_to_store: number,
    store_have_order_payment: number,
    store_have_service_payment: number,
    total_admin_profit_on_store: number,
    total_earning: number,
    total_item_price: number,
    total_order_price: number,
    total_store_income: number,
    total_store_tax_price: number,
    wallet: number,

    total_paid: number,
    total_remaining_to_paid: number,
    total_wallet_income_set: number,

    total_wallet_income_set_in_cash_order: number,
    total_wallet_income_set_in_other_order: number
}

export interface OrderDayTotal {
    date1: number,
    date2: number,
    date3: number,
    date4: number,
    date5: number,
    date6: number,
    date7: number
}

export interface DateList {
    date1: Object,
    date2: Object,
    date3: Object,
    date4: Object,
    date5: Object,
    date6: Object,
    date7: Object
}


@Component({
    selector: 'app-store_weekly_earning_statement',
    templateUrl: './store_weekly_earning_statement.component.html',
   providers: [Helper,
        {provide: 'Window', useValue: window}
    ]
})
@Injectable()
export class StoreWeeklyEarningStatementComponent implements OnInit {
    private order_total: OrderTotal;
    private store_analytic_weekly: StoreAnalyticWeekly;
    private order_day_total: OrderDayTotal;
    date: DateList;
    store_weekly_earning_id: Object;
    currency: String;
    title: any;
    button: any;
    ORDER_STATE: any;
    heading_title: any;

    constructor(private helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);
    }
    ngAfterViewInit() {

        jQuery(".chosen-select").chosen();
        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);
    }

    ngOnInit() {
        this.store_weekly_earning_id = this.helper.router_id.admin.store_weekly_earning_id;
        this.order_total = {

            pay_to_store: 0,
            store_have_order_payment: 0,
            store_have_service_payment: 0,
            total_admin_profit_on_store: 0,
            total_earning: 0,
            total_item_price: 0,
            total_order_price: 0,
            total_store_income: 0,
            total_store_tax_price: 0,
            wallet: 0,
            total_paid: 0,
            total_remaining_to_paid: 0,
            total_wallet_income_set: 0,

            total_wallet_income_set_in_cash_order: 0,
            total_wallet_income_set_in_other_order: 0
        }

        this.store_analytic_weekly = {

            received: 0,
            accepted: 0,
            rejected: 0,
            cancelled: 0,
            order_ready: 0,
            completed: 0,
            acception_ratio: 0,
            rejection_ratio: 0,
            cancellation_ratio: 0,
            completed_ratio: 0,
            total_items: 0
        }

        this.order_day_total = {
            date1: 0,
            date2: 0,
            date3: 0,
            date4: 0,
            date5: 0,
            date6: 0,
            date7: 0
        }

        this.date = {
            date1: null,
            date2: null,
            date3: null,
            date4: null,
            date5: null,
            date6: null,
            date7: null
        }

        this.currency = "";
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;

        this.store_weekly_earning_statement()
    }

    store_weekly_earning_statement() {
        this.helper.http.post('/admin/weekly_statement_for_store', {
            store_weekly_earning_id: this.store_weekly_earning_id
        }).map((res: Response) => res.json()).subscribe(res_data => {

            if (res_data.success == false) {
                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }

                this.order_day_total = {
                    date1: 0,
                    date2: 0,
                    date3: 0,
                    date4: 0,
                    date5: 0,
                    date6: 0,
                    date7: 0
                }
                this.order_total = {
                    pay_to_store: 0,
                    store_have_order_payment: 0,
                    store_have_service_payment: 0,
                    total_admin_profit_on_store: 0,
                    total_earning: 0,
                    total_item_price: 0,
                    total_order_price: 0,
                    total_store_income: 0,
                    total_store_tax_price: 0,
                    wallet: 0,
                    total_paid: 0,
                    total_remaining_to_paid: 0,
                    total_wallet_income_set: 0,

                    total_wallet_income_set_in_cash_order: 0,
                    total_wallet_income_set_in_other_order: 0
                }

                this.store_analytic_weekly = {
                    received: 0,
                    accepted: 0,
                    rejected: 0,
                    cancelled: 0,
                    order_ready: 0,
                    completed: 0,
                    acception_ratio: 0,
                    rejection_ratio: 0,
                    cancellation_ratio: 0,
                    completed_ratio: 0,
                    total_items: 0
                }
                this.date = {
                    date1: null,
                    date2: null,
                    date3: null,
                    date4: null,
                    date5: null,
                    date6: null,
                    date7: null
                }
            }
            else {


                if (res_data.order_total != undefined) {
                    this.order_total = res_data.order_total;
                }
                else {
                    this.order_day_total = {
                        date1: 0,
                        date2: 0,
                        date3: 0,
                        date4: 0,
                        date5: 0,
                        date6: 0,
                        date7: 0
                    }

                }

                if (res_data.order_day_total != undefined) {
                    this.order_day_total = res_data.order_day_total;
                }
                else {
                    this.order_total = {

                        pay_to_store: 0,
                        store_have_order_payment: 0,
                        store_have_service_payment: 0,
                        total_admin_profit_on_store: 0,
                        total_earning: 0,
                        total_item_price: 0,
                        total_order_price: 0,
                        total_store_income: 0,
                        total_store_tax_price: 0,
                        wallet: 0,
                        
                        total_paid: 0,
                        total_remaining_to_paid: 0,
                        total_wallet_income_set: 0,
                        total_wallet_income_set_in_cash_order: 0,
                        total_wallet_income_set_in_other_order: 0
                    }
                }

                this.store_analytic_weekly = res_data.store_analytic_weekly;
                this.date = res_data.date;
                this.currency = res_data.currency;
            }
        });
    }
    
    public download() {
        var doc = new jsPDF();
        doc.setFontType("bold");
        doc.text(20, 20, "TOTAL: " + this.order_total.total_earning.toString() + " " + this.currency);
        
        doc.setFontType("normal");
        doc.text(20, 30, "Total Order: " + this.store_analytic_weekly.order_ready);
        doc.text(20, 40, "Completed Ratio: " + this.store_analytic_weekly.completed_ratio.toString());
        doc.text(20, 50, "Accepted: " + this.store_analytic_weekly.accepted)
        doc.text(20, 60, "Accepeted Ratio: " + this.store_analytic_weekly.acception_ratio.toString());
        doc.text(20, 70, "Total Item Sold: " + this.store_analytic_weekly.total_items);
        
        doc.setFontType("bold");
        doc.text(20, 90, "ORDER EARNING");
        doc.setFontType("normal");
        doc.text(20, 100, "Item Price: " + (this.order_total.total_item_price.toFixed(2)).toString());
        doc.text(20, 110, "Tax Price: " + (this.order_total.total_store_tax_price.toFixed(2)).toString());
        doc.text(20, 120, "Surge Price: " + (this.order_total.total_order_price.toFixed(2)).toString())
        doc.text(20, 130, "Order Price: " + (this.order_total.total_order_price.toFixed(2)).toString());
        doc.text(20, 140, "Store Profit: " + (this.order_total.total_admin_profit_on_store.toFixed(2)).toString());
        doc.text(20, 150, "Wallet: " + (this.order_total.wallet.toFixed(2)).toString());
        
        doc.setFontType("bold");
        doc.text(20, 170, "STORE TRANSACTION");
        doc.setFontType("normal");
        doc.text(20, 180, "Store Earning: " + (this.order_total.total_store_income.toFixed(2)).toString());
        doc.text(20, 190, "Paid: " + (this.order_total.store_have_order_payment.toFixed(2)).toString());
        doc.text(20, 200, "Remaining To Pay: " + (this.order_total.pay_to_store.toFixed(2)).toString());
        doc.text(20, 210, "Total Earnings: " + (this.order_total.total_earning.toFixed(2)).toString());
        doc.text(20, 220, "Received Order Amount: " + (this.order_total.store_have_order_payment.toFixed(2)).toString());
        doc.text(20, 230, "Paid Service Fee: " + (this.order_total.store_have_service_payment.toFixed(2)).toString());
        
        doc.text(20, 240, "Deduct From Wallet: " + (this.order_total.total_wallet_income_set_in_cash_order.toFixed(2)).toString());
        doc.text(20, 250, "Added In wallet: " + (this.order_total.total_wallet_income_set_in_other_order.toFixed(2)).toString());
        
        doc.save('store_weekly_earning_statement.pdf');
    }

}
