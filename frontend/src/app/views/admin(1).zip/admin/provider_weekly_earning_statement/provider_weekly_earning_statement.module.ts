import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProviderWeeklyEarningStatementComponent } from './provider_weekly_earning_statement.component';
import {DropdownModule} from "ng2-dropdown";
import { FormsModule } from '@angular/forms';
import {RouterModule} from "@angular/router";
import { MyDatePickerModule } from 'mydatepicker';
import { TranslateModule } from 'ng2-translate';
@NgModule({
  imports: [
    CommonModule,DropdownModule,FormsModule,RouterModule,MyDatePickerModule,TranslateModule
  ],
  declarations: [ProviderWeeklyEarningStatementComponent]
})
export class ProviderWeeklyEarningStatementModule { }
