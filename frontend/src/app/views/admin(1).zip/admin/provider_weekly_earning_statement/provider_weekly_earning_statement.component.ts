import {Component, ViewContainerRef, Injectable, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Headers, Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Helper} from "../../helper";
declare var jQuery: any;
import 'rxjs/add/operator/toPromise';


//import * as jsPDF from 'jspdf'
declare let jsPDF;

//import {Observable} from 'rxjs';



export interface ProviderAnalyticWeekly {

    received: number,
    accepted: number,
    rejected: number,
    not_answered: number,
    cancelled: number,
    completed: number,
    acception_ratio: number,
    rejection_ratio: number,
    cancellation_ratio: number,
    completed_ratio: number,
    total_online_time: number,
    total_active_job_time: number


}

export interface OrderTotal {


    total_service_price: number,
    total_admin_tax_price: number,
    //total_surge_price: number,
    total_delivery_price: number,
    total_admin_profit_on_delivery: number,
    total_provider_profit: number,
    wallet: number,
    total_earning: number,
    provider_paid_order_payment: number,
    provider_have_cash_payment: number,
    pay_to_provider: number,

    total_paid: number,
    total_remaining_to_paid: number,
    total_wallet_income_set: number,

    total_wallet_income_set_in_cash_order: number,
    total_wallet_income_set_in_other_order: number,
    total_provider_have_cash_payment_on_hand: number



}

export interface OrderDayTotal {
    date1: number,
    date2: number,
    date3: number,
    date4: number,
    date5: number,
    date6: number,
    date7: number
}

export interface DateList {
    date1: Object,
    date2: Object,
    date3: Object,
    date4: Object,
    date5: Object,
    date6: Object,
    date7: Object
}

@Component({
    selector: 'app-provider_weekly_earning_statement',
    templateUrl: './provider_weekly_earning_statement.component.html',
    providers: [Helper,
        {provide: 'Window', useValue: window}
    ]
})
@Injectable()
export class ProviderWeeklyEarningStatementComponent implements OnInit {

    private order_total: OrderTotal;
    private provider_analytic_weekly: ProviderAnalyticWeekly;
    private order_day_total: OrderDayTotal;
    date: DateList;
    provider_weekly_earning_id: Object;
    currency: String;
    title: any;
    button: any;
    ORDER_STATE: any;
    heading_title: any;


    constructor(private helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);
    }

    ngAfterViewInit() {

        jQuery(".chosen-select").chosen();
        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);
    }

    ngOnInit() {
        this.provider_weekly_earning_id = this.helper.router_id.admin.provider_weekly_earning_id;
        this.order_total = {
            total_service_price: 0,
            total_admin_tax_price: 0,
            //total_surge_price: 0,
            total_delivery_price: 0,
            total_admin_profit_on_delivery: 0,
            total_provider_profit: 0,
            wallet: 0,
            total_earning: 0,
            provider_paid_order_payment: 0,
            provider_have_cash_payment: 0,
            pay_to_provider: 0,

            total_paid: 0,
            total_remaining_to_paid: 0,
            total_wallet_income_set: 0,

            total_wallet_income_set_in_cash_order: 0,
            total_wallet_income_set_in_other_order: 0,
            total_provider_have_cash_payment_on_hand: 0
        }
        this.provider_analytic_weekly = {
            received: 0,
            accepted: 0,
            rejected: 0,
            not_answered: 0,
            cancelled: 0,
            completed: 0,
            acception_ratio: 0,
            rejection_ratio: 0,
            cancellation_ratio: 0,
            completed_ratio: 0,
            total_online_time: 0,
            total_active_job_time: 0
        }

        this.order_day_total = {
            date1: 0,
            date2: 0,
            date3: 0,
            date4: 0,
            date5: 0,
            date6: 0,
            date7: 0
        }

        this.date = {
            date1: null,
            date2: null,
            date3: null,
            date4: null,
            date5: null,
            date6: null,
            date7: null
        }

        this.currency = "";
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;

        this.provider_weekly_earning_statement()
    }



    provider_weekly_earning_statement() {
        this.helper.http.post('/admin/weekly_statement_for_provider', {
            provider_weekly_earning_id: this.provider_weekly_earning_id
        }).map((res: Response) => res.json()).subscribe(res_data => {

            if (res_data.success == false) {
                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }

                this.order_day_total = {
                    date1: 0,
                    date2: 0,
                    date3: 0,
                    date4: 0,
                    date5: 0,
                    date6: 0,
                    date7: 0
                }
                this.order_total = {

                    total_service_price: 0,
                    total_admin_tax_price: 0,
                    //total_surge_price: 0,
                    total_delivery_price: 0,
                    total_admin_profit_on_delivery: 0,
                    total_provider_profit: 0,
                    wallet: 0,
                    total_earning: 0,
                    provider_paid_order_payment: 0,
                    provider_have_cash_payment: 0,
                    pay_to_provider: 0,

                    total_paid: 0,
                    total_remaining_to_paid: 0,
                    total_wallet_income_set: 0,

                    total_wallet_income_set_in_cash_order: 0,
                    total_wallet_income_set_in_other_order: 0,
                    total_provider_have_cash_payment_on_hand: 0
                }

                this.provider_analytic_weekly = {
                    received: 0,
                    accepted: 0,
                    rejected: 0,
                    not_answered: 0,
                    cancelled: 0,
                    completed: 0,
                    acception_ratio: 0,
                    rejection_ratio: 0,
                    cancellation_ratio: 0,
                    completed_ratio: 0,
                    total_online_time: 0,
                    total_active_job_time: 0
                }
                this.date = {
                    date1: null,
                    date2: null,
                    date3: null,
                    date4: null,
                    date5: null,
                    date6: null,
                    date7: null
                }
            }
            else {


                if (res_data.order_total != undefined) {
                    this.order_total = res_data.order_total;
                }
                else {
                    this.order_day_total = {
                        date1: 0,
                        date2: 0,
                        date3: 0,
                        date4: 0,
                        date5: 0,
                        date6: 0,
                        date7: 0
                    }

                }

                if (res_data.order_day_total != undefined) {
                    this.order_day_total = res_data.order_day_total;
                }
                else {
                    this.order_total = {

                        total_service_price: 0,
                        total_admin_tax_price: 0,
                        //total_surge_price: 0,
                        total_delivery_price: 0,
                        total_admin_profit_on_delivery: 0,
                        total_provider_profit: 0,
                        wallet: 0,
                        total_earning: 0,
                        provider_paid_order_payment: 0,
                        provider_have_cash_payment: 0,
                        pay_to_provider: 0,
                        total_paid: 0,
                        total_remaining_to_paid: 0,
                        total_wallet_income_set: 0,

                        total_wallet_income_set_in_cash_order: 0,
                        total_wallet_income_set_in_other_order: 0,
                        total_provider_have_cash_payment_on_hand: 0
                    }
                }

                this.provider_analytic_weekly = res_data.provider_analytic_weekly;
                this.date = res_data.date;
                this.currency = res_data.currency;
                //this.download();

            }
        });
    }

    public download() {
        var doc = new jsPDF();
        doc.setFontType("bold");
        doc.text(20, 20, "TOTAL: " + this.order_total.total_earning.toString() + " " + this.currency);
        
        doc.setFontType("normal");
        doc.text(20, 30, "Total Online Time: " + this.provider_analytic_weekly.total_online_time.toString());
        doc.text(20, 40, "Completed Ratio: " + this.provider_analytic_weekly.completed_ratio.toString());
        doc.text(20, 50, "Completed Deliveries: " + this.provider_analytic_weekly.completed)
        doc.text(20, 60, "Accepeted Ratio: " + this.provider_analytic_weekly.acception_ratio.toString());
        doc.text(20, 70, "Total Deliveries: " + this.provider_analytic_weekly.received);
        
        doc.setFontType("bold");
        doc.text(20, 90, "ORDER EARNING");
        doc.setFontType("normal");
        doc.text(20, 100, "Service Price: " + (this.order_total.total_service_price.toFixed(2)).toString());
        doc.text(20, 110, "Tax Price: " + (this.order_total.total_admin_tax_price.toFixed(2)).toString());
        //doc.text(20, 120, "Surge Price: " + (this.order_total.total_surge_price.toFixed(2)).toString())
        doc.text(20, 130, "Delivery Price: " + (this.order_total.total_delivery_price.toFixed(2)).toString());
        doc.text(20, 140, "Deliveryman Profit: " + (this.order_total.total_provider_profit.toFixed(2)).toString());
        doc.text(20, 150, "Wallet: " + (this.order_total.wallet.toFixed(2)).toString());
        
        doc.setFontType("bold");
        doc.text(20, 170, "PROVIDER TRANSACTION");
        doc.setFontType("normal");
        doc.text(20, 180, "Provider Earning: " + (this.order_total.total_provider_profit.toFixed(2)).toString());
        doc.text(20, 190, "Paid: " + (this.order_total.provider_paid_order_payment.toFixed(2)).toString());
        doc.text(20, 200, "Remaining To Pay: " + (this.order_total.pay_to_provider.toFixed(2)).toString());
        doc.text(20, 210, "Total Earnings: " + (this.order_total.total_earning.toFixed(2)).toString());
        doc.text(20, 220, "Paid Order Amount: " + (this.order_total.provider_paid_order_payment.toFixed(2)).toString());
        doc.text(20, 230, "Cash Amount: " + (this.order_total.provider_have_cash_payment.toFixed(2)).toString());
        doc.text(20, 240, "Cash On Hand: " + (this.order_total.total_provider_have_cash_payment_on_hand.toFixed(2)).toString());
        doc.text(20, 250, "Deduct From Wallet: " + (this.order_total.total_wallet_income_set_in_cash_order.toFixed(2)).toString());
        doc.text(20, 260, "Added In wallet: " + (this.order_total.total_wallet_income_set_in_other_order.toFixed(2)).toString());
        

        
        
        //doc.addPage();
        //doc.text(20, 20, '1Do you like that ?');
        //        doc.addPage();
        //        doc.text(20, 20, '2Do you like that?');
        //        doc.addPage();
        //        doc.text(20, 20, '3Do you like that?');
        // Save the PDF
        doc.save('provider_weekly_earning_statement.pdf');
    }

}
