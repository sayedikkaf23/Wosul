import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload_document',
  templateUrl: './upload_document.component.html'
})
export class UploadDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
