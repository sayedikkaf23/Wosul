import {Component, OnInit} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Helper} from "../../helper";
import * as moment from 'moment-timezone';

@Component({
    selector: 'app-view_order_earning_detail',
    templateUrl: './view_order_earning_detail.component.html',
    providers: [Helper]
})
export class ViewOrderEarningDetailComponent implements OnInit {

    order_id: Object;
    order_detail: any[];
    currency_sign: any;
    //total_order_price: number;
    order_total: number;
    product_item_total: number;
    product_item_total_array: number[];
    product_item_specification_total: number;
    product_item_specification_total_array: number[];
    product_specification_total_array: any[];
    total_item: number;

    total_time: number;
    total_distance: number;


    base_price: number;
    total_distance_price: number;
    total_time_price: number;
    total_service_price: number;
    total_admin_tax_price: number;
    total_surge_price: number;
    delivery_price: number;
    promo_payment: number;
    total_delivery_price: number;
    total_cart_price: number;

    total_order_price: number;
    order_price: number;
    service_tax: number;
    total_store_tax_price: number;


    total: number;
    wallet_payment: number;

    cash_payment: number;
    card_payment: number;

    store_have_service_payment: number;
    store_have_order_payment: number;
    pay_to_store: number;
    total_store_income: number;
    store_income_set_in_wallet: number;



    provider_paid_order_payment: number;
    provider_have_cash_payment: number;
    pay_to_provider: number;
    total_provider_income: number;
    provider_income_set_in_wallet: number;

    total_admin_profit_on_store: number;
    total_admin_profit_on_delivery: number;
    admin_profit_value_on_delivery: number;
    admin_profit_value_on_store: number;

    admin_profit_mode_on_store: number;
    admin_profit_mode_on_delivery: number;

    current_rate: number;

    is_distance_unit_mile: Boolean;
    is_promo_for_delivery_service: Boolean;
    is_store_pay_delivery_fees: Boolean;


    user_first_name: String;
    user_last_name: String;
    user_email: String;
    user_phone: String;
    user_address: String;


    delivery_user_name: String;
    delivery_user_phone: String;
    delivery_user_address: String;



    provider_first_name: String;
    provider_last_name: String;
    provider_email: String;
    provider_phone: String;
    vehicle_name: String;

    store_name: String;
    store_email: String;
    store_address: String;
    store_phone: String;


    invoice_number: String;
    timezone: string;


    title: any;
    button: any;
    heading_title: any;
    status: any;
    lable_title: any;

    ORDER_STATE: any;
    ORDER_STATUS_ID: any;
    DATE_FORMAT: any;
    order_status: number;

    order_status_id: number;


    delivery_status: number;

    created_at: any;

    completed_at: any;


    request_created_at: any;
    request_completed_at: any;

    date_time: any[];

    myLoading: boolean = true;
    new_date: any;
    my_date: any;

    completed_at2: any;
    completed_at3: any;

    constructor(public helper: Helper) {
    }


    ngOnInit() {
        this.order_id = this.helper.router_id.admin.view_order_earning_id;
        this.order_total = 0;
        this.total_item = 0;
        this.total_time = 0;
        this.total_distance = 0;

        this.base_price = 0;
        this.total_distance_price = 0;
        this.total_time_price = 0;
        this.total_service_price = 0;
        this.total_admin_tax_price = 0;
        this.total_surge_price = 0;
        this.delivery_price = 0;
        this.promo_payment = 0;
        this.total_delivery_price = 0;
        this.total_cart_price = 0;

        this.total_order_price = 0;
        this.order_price = 0;
        this.service_tax = 0;
        this.total_store_tax_price = 0;

        this.total = 0;
        this.wallet_payment = 0;
        this.cash_payment = 0;
        this.card_payment = 0;


        this.store_have_service_payment = 0;
        this.store_have_order_payment = 0;
        this.total_store_income = 0;
        this.pay_to_store = 0;
        this.store_income_set_in_wallet = 0;

        this.provider_have_cash_payment = 0;
        this.provider_paid_order_payment = 0;
        this.total_provider_income = 0;
        this.pay_to_provider = 0;
        this.provider_income_set_in_wallet = 0;


        this.total_admin_profit_on_store = 0;
        this.total_admin_profit_on_delivery = 0;
        this.admin_profit_value_on_delivery = 0;
        this.admin_profit_value_on_store = 0;

        this.admin_profit_mode_on_store = 0;
        this.admin_profit_mode_on_delivery = 0;

        this.current_rate = 1;
        this.is_distance_unit_mile = false;
        this.is_promo_for_delivery_service = false;
        this.is_store_pay_delivery_fees = false;



        this.product_item_total = 0;
        this.product_item_total_array = [];
        this.product_item_specification_total = 0;
        this.product_item_specification_total_array = [];
        this.product_specification_total_array = [];
        this.provider_first_name = "";
        this.provider_last_name = "";
        this.provider_email = "";
        this.vehicle_name = "";
        this.provider_phone = "";


        this.store_name = "";
        this.store_email = "";
        this.store_address = "";
        this.store_phone = "";

        this.user_first_name = "";
        this.user_last_name = "";
        this.user_email = "";
        this.user_phone = "";
        this.user_address = "";



        this.delivery_user_name = "";
        this.delivery_user_phone = "";
        this.delivery_user_address = "";
        this.timezone = "";


        this.ORDER_STATE = this.helper.ORDER_STATE;
        this.DATE_FORMAT = this.helper.DATE_FORMAT;
        this.ORDER_STATUS_ID = this.helper.ORDER_STATUS_ID;
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.status = this.helper.status;
        this.lable_title = this.helper.lable_title;

        this.helper.http.post('/admin/get_order_earning_detail', {order_id: this.order_id}).map((res_data: Response) => res_data.json()).subscribe(res_data => {

            this.myLoading = false;

            if (res_data.success == false) {

                //this.helper.router.navigate(['admin/order_earning']);

            }
            else {

                this.user_first_name = res_data.order.user_detail.first_name
                this.user_last_name = res_data.order.user_detail.last_name
                this.user_email = res_data.order.user_detail.email
                this.user_phone = res_data.order.user_detail.country_phone_code + res_data.order.user_detail.phone
                this.user_address = res_data.order.user_detail.address



                this.store_name = res_data.order.store_detail.name
                this.store_email = res_data.order.store_detail.email
                this.store_address = res_data.order.store_detail.address
                this.store_phone = res_data.order.store_detail.country_phone_code + res_data.order.store_detail.phone


                this.invoice_number = res_data.order.order_payment_detail.invoice_number
                this.order_status = res_data.order.order_status
                this.order_status_id = res_data.order.order_status_id

                this.date_time = res_data.order.date_time;
                this.timezone = res_data.order.timezone;






                this.total_time = res_data.order.order_payment_detail.total_time
                this.total_distance = res_data.order.order_payment_detail.total_distance

                //this.base_price = res_data.order.order_payment_detail.total_base_price;
                //this.total_distance_price = res_data.order.order_payment_detail.distance_price;
                //this.total_time_price = res_data.order.order_payment_detail.total_time_price;
                this.total_service_price = res_data.order.order_payment_detail.total_service_price;
                this.total_admin_tax_price = res_data.order.order_payment_detail.total_admin_tax_price;
                //this.total_surge_price = res_data.order.order_payment_detail.total_surge_price;
                this.delivery_price = res_data.order.order_payment_detail.delivery_price;
                this.promo_payment = res_data.order.order_payment_detail.promo_payment;
                this.total_delivery_price = res_data.order.order_payment_detail.total_delivery_price;
                this.total_cart_price = res_data.order.order_payment_detail.total_cart_price;


                this.total_order_price = res_data.order.order_payment_detail.total_order_price;
                this.order_price = res_data.order.order_payment_detail.order_price;
                this.service_tax = res_data.order.order_payment_detail.service_tax;
                this.total_store_tax_price = res_data.order.order_payment_detail.total_store_tax_price;

                this.total = res_data.order.order_payment_detail.total;
                this.wallet_payment = res_data.order.order_payment_detail.wallet_payment;
                this.cash_payment = res_data.order.order_payment_detail.cash_payment;
                this.card_payment = res_data.order.order_payment_detail.card_payment;


                this.store_have_service_payment = res_data.order.order_payment_detail.store_have_service_payment;
                this.store_have_order_payment = res_data.order.order_payment_detail.store_have_order_payment;
                this.total_store_income = res_data.order.order_payment_detail.total_store_income;
                this.pay_to_store = res_data.order.order_payment_detail.pay_to_store;
                this.store_income_set_in_wallet = res_data.order.order_payment_detail.store_income_set_in_wallet;


                this.provider_have_cash_payment = res_data.order.order_payment_detail.provider_have_cash_payment;
                this.provider_paid_order_payment = res_data.order.order_payment_detail.provider_paid_order_payment;
                this.total_provider_income = res_data.order.order_payment_detail.total_provider_income;
                this.pay_to_provider = res_data.order.order_payment_detail.pay_to_provider;
                this.provider_income_set_in_wallet = res_data.order.order_payment_detail.provider_income_set_in_wallet;




                this.total_admin_profit_on_store = res_data.order.order_payment_detail.total_admin_profit_on_store;
                this.total_admin_profit_on_delivery = res_data.order.order_payment_detail.total_admin_profit_on_delivery;
                this.admin_profit_value_on_delivery = res_data.order.order_payment_detail.admin_profit_value_on_delivery;
                this.admin_profit_value_on_store = res_data.order.order_payment_detail.admin_profit_value_on_store;
                this.admin_profit_mode_on_store = res_data.order.order_payment_detail.admin_profit_mode_on_store;
                this.admin_profit_mode_on_delivery = res_data.order.order_payment_detail.admin_profit_mode_on_delivery;



                this.current_rate = res_data.order.order_payment_detail.current_rate;
                this.is_distance_unit_mile = res_data.order.order_payment_detail.is_distance_unit_mile;
                this.is_promo_for_delivery_service = res_data.order.order_payment_detail.is_promo_for_delivery_service;
                this.is_store_pay_delivery_fees = res_data.order.order_payment_detail.is_store_pay_delivery_fees;
                console.log(res_data.order.order_payment_detail.is_store_pay_delivery_fees);


                this.order_detail = res_data.order.cart_detail.order_details
                this.currency_sign = res_data.order.country_detail.currency_sign


                res_data.order.cart_detail.order_details.forEach((product) => {
                    product.items.forEach((item) => {
                        this.order_total = this.order_total + (item.item_price + item.total_specification_price) * item.quantity
                        this.product_item_total = this.product_item_total + (item.item_price + item.total_specification_price) * item.quantity
                        this.total_item = this.total_item + 1;
                        item.specifications.forEach((specification) => {
                            this.product_item_specification_total = this.product_item_specification_total + specification.specification_price;
                        })
                        this.product_item_specification_total_array.push(this.product_item_specification_total)
                        this.product_item_specification_total = 0;
                    })
                    this.product_specification_total_array.push(this.product_item_specification_total_array)
                    this.product_item_specification_total_array = [];
                    this.product_item_total_array.push(this.product_item_total)
                    this.product_item_total = 0;
                })

                if (res_data.order.cart_detail.destination_addresses.length > 0) {
                    this.delivery_user_name = res_data.order.cart_detail.destination_addresses[0].user_details.name
                    this.delivery_user_phone = res_data.order.cart_detail.destination_addresses[0].user_details.country_phone_code + res_data.order.cart_detail.destination_addresses[0].user_details.phone
                    this.delivery_user_address = res_data.order.cart_detail.destination_addresses[0].address
                }


                if (res_data.order.timezone != "") {
                    if (res_data.order.created_at != null) {
                        this.created_at = moment(res_data.order.created_at).tz(this.timezone).format('DD MMM YYYY HH:mm');
                    }
                    if (res_data.order.completed_at != null) {
                        this.completed_at = moment(res_data.order.completed_at).tz(this.timezone).format('DD MMM YYYY HH:mm');
                    }

                    if (res_data.order.request_detail !== undefined) {

                        if (res_data.order.request_detail.created_at != null) {
                            this.request_created_at = moment(res_data.order.request_detail.created_at).tz(this.timezone).format('DD MMM YYYY HH:mm');
                        }
                        if (res_data.order.request_detail.completed_at != null) {
                            this.request_completed_at = moment(res_data.order.request_detail.completed_at).tz(this.timezone).format('DD MMM YYYY HH:mm');
                        }

                    }

                }

                this.delivery_status = res_data.order.request_detail.delivery_status


                if (res_data.order.request_detail !== undefined) {
                    if (res_data.order.provider_detail.length > 0) {
                        this.provider_first_name = res_data.order.provider_detail[0].first_name
                        this.provider_last_name = res_data.order.provider_detail[0].last_name
                        this.provider_email = res_data.order.provider_detail[0].email
                        this.provider_phone = res_data.order.provider_detail[0].country_phone_code + res_data.order.provider_detail[0].phone
                    }
                }


            }
        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });
    }


}
