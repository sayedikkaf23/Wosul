import {Component, OnInit, ViewContainerRef} from '@angular/core';
import {Helper} from "../../helper";
import {Http, Response} from '@angular/http';
declare var jQuery: any;
@Component({
    selector: 'app-city',
    templateUrl: './city.component.html',
    providers: [Helper]
})
export class cityComponent implements OnInit {
    
    country_list: any[];
    filtered_country_list: any[] = [];
    title: any;
    button: any;
    heading_title: any;
    public message: string = "";
    public class: string;
    selected_country: string;
    filter_country_name: String = "";
    myLoading: boolean = true;

    constructor(public helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);
    }

    ngAfterViewInit() {
        jQuery(".chosen-select").chosen();
        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);
    }

    activeRoute(routename: string): boolean {
        return this.helper.router.url.indexOf(routename) > -1;
    }

    ngOnInit() {

        this.helper.message();

        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.selected_country = this.title.all

        jQuery(this.helper.elementRef.nativeElement).find('#selected_country').on('change', (evnt, res_data) => {

            this.selected_country = res_data.selected;
        });
        
        

        this.helper.http.post('/admin/city_list_search_sort', {}).map((res: Response) => res.json()).subscribe(res_data => {
            this.myLoading = false;

            if (res_data.success == false) {
                this.helper.data.storage = {
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }

                this.country_list = [];
                this.filtered_country_list = [];

            }
            else {

                this.country_list = res_data.countries;
                this.filtered_country_list = res_data.countries;
            }

        },
        (error: any) => {
            this.myLoading=false;
                this.helper.http_status(error)
        })
    }


    filter_country(data) {
        data = data.replace(/^\s+|\s+$/g, '');
        data = data.replace(/ +(?= )/g, '');
        data = new RegExp(data, "gi");

        var country_array = [];
        this.country_list.forEach((country) => {

            var city_array = country.cities.filter((city_data) => {
                var a = city_data.city_name.match(data);
                return a !== null;
            })
            if (city_array.length > 0) {
                country_array.push({
                    _id: country._id, country_name: country.country_name, cities: city_array
                })
            }
        });
        this.filtered_country_list = country_array;
    }




    is_business_change(id, event) {
        this.helper.http.post('/admin/toggle_change', {city_id: id, is_business: event}).map((res: Response) => res.json()).subscribe(res_data => {

            if (res_data.success == false) {

            }
        });

    }

    is_cash_payment_mode_change(id, event) {
        this.helper.http.post('/admin/toggle_change', {city_id: id, is_cash_payment_mode: event}).map((res: Response) => res.json()).subscribe(res_data => {

            if (res_data.success == false) {

            }
        });

    }

    is_other_payment_mode_change(id, event) {
        this.helper.http.post('/admin/toggle_change', {city_id: id, is_other_payment_mode: event}).map((res: Response) => res.json()).subscribe(res_data => {

            if (res_data.success == false) {

            }
        });

    }
    editCity(id) {
        this.helper.router_id.admin.city_id = id;
        this.helper.router.navigate(['admin/city/edit']);
    }


}
