import {Component, OnInit, ViewContainerRef, ViewChild} from '@angular/core';
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {ModalComponent} from 'ng2-bs3-modal/ng2-bs3-modal';
import {Helper} from "../../helper";
declare var jQuery: any;
declare var c3: any;


export interface ProviderEdit {

    provider_id: Object,
    first_name: String,
    last_name: String,
    email: String,
    //zipcode: String,
    device_type: String,
    user_rate: Number,
    total_online_time: Number,
    total_active_job_time: Number,
    total_rejected_orders: Number,



    country_name: String,
    city_name: String,
    address: String,
    country_phone_code: String,
    phone: Number,
    
    _id: Object,
    unique_id:Number,

    referral_code: String,
    wallet: Number,
    total_referrals: Number,
    referred_by: Object,
    //vehicle_id: Object,

    wallet_currency_code: String,
    app_version: String,
    image_url: String,
    //vehicle_model: String,
    //vehicle_number: String,
    comments: String,
    referred_provider_first_name: String,
    referred_provider_last_name: String,
    vehicle_name: String,

    is_document_uploaded: Boolean,
    is_phone_number_verified: Boolean,
    is_email_verified: Boolean,
    is_in_delivery: Boolean,
    is_online: Boolean,
    is_active_for_job: Boolean,
    is_approved: Boolean,
    total_orders: Number
    


}

export interface OrderDetail {
    total_orders: Number,
    accepted_orders: Number,
    completed_orders: Number,
    cancelled_orders: Number,
    completed_order_percentage: Number
}

@Component({
    selector: 'app-edit_provider',
    templateUrl: './edit_provider.component.html',
    providers: [Helper]
})
export class EditProviderComponent implements OnInit {

    private provider_edit: ProviderEdit;
    private order_detail: OrderDetail;
    title: any;
    button: any;
    heading_title: any;
    minimum_phone_number_length: number;
    maximum_phone_number_length: number;
    provider: any;
    provider_id: Object;
    edit: Boolean;
    vehicle_list: any[];
    myLoading: boolean = true;
    constructor(public helper: Helper, public vcr: ViewContainerRef) {
        helper.toastr.setRootViewContainerRef(vcr);

    }

    ngAfterViewInit() {

        jQuery("#vehicle").chosen({disable_search: true});
        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);
    }


    ngOnInit() {
        this.provider_edit = {
            provider_id: "",
            //vehicle_id: "",
            first_name: "",
            last_name: "",
            email: "",

            device_type: "",
            user_rate: null,
            total_online_time: null,
            total_active_job_time: null,
            total_rejected_orders: null,
            is_in_delivery: false,
            is_document_uploaded: false,


            //zipcode: "",
            country_name: "",
            city_name: "",
            vehicle_name: "",
            address: "",
            country_phone_code: "",
            phone: null,
             _id: "",
            unique_id: null,
            // latitude: null,
            // longitude: null,
            referral_code: "",
            wallet: null,
            total_referrals: null,
            referred_by: "",
            wallet_currency_code: "",
            app_version: "",
            image_url: "",
            //vehicle_model: "",
            //vehicle_number: "",
            comments: "",
            referred_provider_first_name: "",
            referred_provider_last_name: "",

            //is_document_uploaded: false,
            is_phone_number_verified: false,
            is_email_verified: false,
            //is_in_delivery: false,
            is_online: false,
            is_active_for_job: false,
            is_approved: false,
            total_orders: null
            


        }

        this.order_detail = {
            total_orders: 0,
            accepted_orders: 0,
            completed_orders: 0,
            cancelled_orders: 0,
            completed_order_percentage: 0
        }
        this.provider_id = this.helper.router_id.admin.provider_id;
        var provider = JSON.parse(localStorage.getItem('provider'));

//        this.helper.http.get('/admin/vehicle_list_for_provider').map((res: Response) => res.json()).subscribe(res => {
//            this.vehicle_list = res.vehicles;
//
//        });
//
//        jQuery(this.helper.elementRef.nativeElement).find('#vehicle').on('change', (evnt, res_data) => {
//
//            this.provider_edit.vehicle_id = res_data.selected;
//        });





        this.helper.http.post('/admin/get_provider_detail', {provider_id: this.provider_id}).map((response: Response) => response.json()).subscribe(res_data => {
            this.myLoading = false;
            if (res_data.success == false) {
                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
            }
            else {

                this.order_detail = res_data.order_detail;

                let chart31 = c3.generate({
                    bindto: '#c1',
                    data: {

                        columns: [
                            [this.title.completed_order, this.order_detail.completed_order_percentage]
                        ],
                        type: 'gauge',
                    },
                    legend: {
                        show: true
                    },
                    gauge: {
                        label: {
                            show: false // to turn off the min/max labels.
                        },
                        width: 30 // for adjusting arc thickness
                    },
                    color: {
                        pattern: ['#1e1e1e'], // the three color levels for the percentage values.

                    }
                });

                this.provider_edit.total_orders = res_data.provider.total_orders;
                this.provider_edit.total_active_job_time = res_data.provider.total_active_job_time;
                this.provider_edit.first_name = res_data.provider.first_name;
                this.provider_edit.last_name = res_data.provider.last_name;
                this.provider_edit.email = res_data.provider.email;
                
                
                this.provider_edit._id = res_data.provider._id;
                this.provider_edit.unique_id = res_data.provider.unique_id;

                this.provider_edit.device_type = res_data.provider.device_type;
                this.provider_edit.user_rate = res_data.provider.user_rate;
                this.provider_edit.total_online_time = res_data.provider.total_online_time;
                this.provider_edit.total_rejected_orders = res_data.provider.total_rejected_orders;



                this.provider_edit.is_document_uploaded = res_data.provider.is_document_uploaded;
                this.provider_edit.is_in_delivery = res_data.provider.is_in_delivery;


                //this.provider_edit.zipcode = res_data.provider.zipcode;
                this.minimum_phone_number_length = res_data.provider.country_details.minimum_phone_number_length;
                this.maximum_phone_number_length = res_data.provider.country_details.maximum_phone_number_length;


                this.provider_edit.country_name = res_data.provider.country_details.country_name;
                this.provider_edit.city_name = res_data.provider.city_details.city_name;
                this.provider_edit.address = res_data.provider.address;
                this.provider_edit.country_phone_code = res_data.provider.country_phone_code;
                this.provider_edit.phone = res_data.provider.phone;
               // this.provider_edit.vehicle_model = res_data.provider.vehicle_model;
               // this.provider_edit.vehicle_id = res_data.provider.vehicle_id;



                this.provider_edit.referral_code = res_data.provider.referral_code;


                if (res_data.provider.vehicles_details.length > 0) {
                    this.provider_edit.vehicle_name = res_data.provider.vehicles_details[0].vehicle_name;

                }

                if (res_data.provider.referred_provider_details.length > 0) {
                    this.provider_edit.referred_provider_first_name = res_data.provider.referred_provider_details[0].first_name;
                    this.provider_edit.referred_provider_last_name = res_data.provider.referred_provider_details[0].last_name;
                }
                this.provider_edit.wallet_currency_code = res_data.provider.wallet_currency_code;
                this.provider_edit.wallet = res_data.provider.wallet;
                this.provider_edit.total_referrals = res_data.provider.total_referrals;

                this.provider_edit.referred_by = res_data.provider.referred_by;
                this.provider_edit.app_version = res_data.provider.app_version;


                // this.provider_edit.is_document_uploaded = res_data.provider.is_document_uploaded;
                this.provider_edit.is_phone_number_verified = res_data.provider.is_phone_number_verified;
                this.provider_edit.is_email_verified = res_data.provider.is_email_verified;
                //this.provider_edit.is_in_delivery = res_data.provider.is_in_delivery;
                this.provider_edit.is_online = res_data.provider.is_online;
                this.provider_edit.is_active_for_job = res_data.provider.is_active_for_job;
                this.provider_edit.is_approved = res_data.provider.is_approved;


                // this.provider_edit.latitude = res_data.provider.location[0];
                // this.provider_edit.longitude = res_data.provider.location[1];
                //this.provider_edit.vehicle_number = res_data.provider.vehicle_number;
                this.provider_edit.image_url = res_data.provider.image_url;
                this.provider_edit.comments = res_data.provider.comments;


            }


        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.edit = false;

        jQuery(window).resize(function () {
            if (jQuery(window).width() < 454) {
                jQuery('.box').removeClass('col-xs-1');
                jQuery('.total').removeClass('col-xs-5');
                jQuery('.box').addClass('col-xs-2');
                jQuery('.total').addClass('col-xs-10');
                jQuery('.box1').css('padding', '')
                jQuery('.total1').css('padding', '')
            } else {
                jQuery('.box').removeClass('col-xs-2');
                jQuery('.total').removeClass('col-xs-10');
                jQuery('.box').addClass('col-xs-1');
                jQuery('.total').addClass('col-xs-5');
                jQuery('.box1').css('padding', 0)
                jQuery('.total1').css('padding', 0)
            }
        });
        setTimeout(function () {
            if (jQuery(window).width() < 454) {
                jQuery('.box').removeClass('col-xs-1');
                jQuery('.total').removeClass('col-xs-5');
                jQuery('.box').addClass('col-xs-2');
                jQuery('.total').addClass('col-xs-10');
                jQuery('.box1').css('padding', '')
                jQuery('.total1').css('padding', '')
            } else {
                jQuery('.box').removeClass('col-xs-2');
                jQuery('.total').removeClass('col-xs-10');
                jQuery('.box').addClass('col-xs-1');
                jQuery('.total').addClass('col-xs-5');
                jQuery('.box1').css('padding', 0)
                jQuery('.total1').css('padding', 0)
            }
        }, 500);

    }

    public formData = new FormData();

    change_image($event) {

        const files = $event.target.files || $event.srcElement.files;
        const image_url = files[0];

        if (image_url.type == "image/jpeg" || image_url.type == "image/jpg" || image_url.type == "image/png") {
            this.formData = new FormData();
            this.formData.append('image_url', image_url);

            var reader = new FileReader();

            reader.onload = (e: any) => {
                this.provider_edit.image_url = e.target.result
            }
            reader.readAsDataURL(image_url);
        }
    }


    UpdateProvider(provider_data) {
        this.myLoading = true;
        this.formData.append('provider_id', provider_data.provider_id);
        this.formData.append('phone', provider_data.phone);
        this.formData.append('email', provider_data.email);
        this.formData.append('first_name', provider_data.first_name);
        this.formData.append('last_name', provider_data.last_name);
        this.formData.append('address', provider_data.address);
        this.formData.append('latitude', provider_data.latitude);
        this.formData.append('longitude', provider_data.longitude);
        //this.formData.append('zipcode', provider_data.zipcode);
        //this.formData.append('vehicle_model', provider_data.vehicle_model);
        //this.formData.append('vehicle_number', provider_data.vehicle_number);
        //this.formData.append('vehicle_id', provider_data.vehicle_id);
        
        this.formData.append('is_phone_number_verified', provider_data.is_phone_number_verified);
        this.formData.append('is_email_verified', provider_data.is_email_verified);
        this.formData.append('is_online', provider_data.is_online);
        this.formData.append('is_active_for_job', provider_data.is_active_for_job);
        this.formData.append('is_approved', provider_data.is_approved);
        this.formData.append('comments', provider_data.comments);


        this.helper.http.post('/admin/update_provider', this.formData).map((response: Response) => response.json()).subscribe(res_data => {
            this.myLoading = false;
            jQuery('#remove').click();

            if (res_data.success == false) {

                this.helper.data.storage = {
                    "code": res_data.error_code,
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
                this.helper.message();

                this.formData = new FormData();
                this.provider_edit.first_name = this.provider.first_name;
                this.provider_edit.last_name = this.provider.last_name;
                //this.provider_edit.vehicle_id = this.provider.vehicle_id;
                //this.provider_edit.zipcode = this.provider.zipcode;
                this.provider_edit.address = this.provider.address;
                this.provider_edit.phone = this.provider.phone;
                this.provider_edit.email = this.provider.email;
               // this.provider_edit.vehicle_model = this.provider.vehicle_model;
               // this.provider_edit.vehicle_number = this.provider.vehicle_number;
                this.provider_edit.image_url = this.provider.image_url;
                this.provider_edit.is_phone_number_verified = this.provider.is_phone_number_verified;
                this.provider_edit.is_email_verified = this.provider.is_email_verified;
                this.provider_edit.is_online = this.provider.is_online;
                this.provider_edit.is_active_for_job = this.provider.is_active_for_job;
                this.provider_edit.is_approved = this.provider.is_approved;
                this.provider_edit.comments = this.provider.comments;

            }
            else {
                localStorage.setItem('provider', JSON.stringify(res_data.provider));
                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
                this.helper.router.navigate(['admin/pending_for_approval']);
                this.helper.message();
            }
        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });

    }

}
