import {Component, OnInit} from '@angular/core';

import {Helper} from "../../helper";
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

declare var google: any;
declare var jQuery: any;

@Component({
    selector: 'app-all-city',
    templateUrl: './all-city.component.html',
    providers: [Helper]
})
export class AllCityComponent implements OnInit {

    constructor(private helper: Helper) {}
    map: any = '';
    drawingManager: any;
    city_list: any[] = [];
    filtered_city_list: any = [];
    country_list: any[] = [];
    selected_country: string = "All";
    title: any;
    button: any;
    heading_title: any;
    ngAfterViewInit() {
        jQuery(".chosen-select").chosen({disable_search: true});

        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);


    }

    ngOnInit() {
        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        this.map = new google.maps.Map(document.getElementById('map'), {
            zoom: 7,
            streetViewControl: false,
            center: {lat: 22, lng: 70}
        });

        var infoWindow = null;

//        this.helper.http.get('api/admin/get_country_list').map((res: Response) => res.json()).subscribe(res_data => {
//
//            if (res_data.success) {
//                this.country_list = res_data.countries;
//              
//            }
//            else {
//                this.country_list = [];
//            }
//
//        });
//        setTimeout(function () {
//            jQuery("#selected_country").trigger("chosen:updated");
//        }, 1000);

        var input = document.getElementById('search');
        var searchBox = new google.maps.places.SearchBox(input);
        this.map.addListener('bounds_changed', () => {
            searchBox.setBounds(this.map.getBounds());
        });
        searchBox.addListener('places_changed', () => {
            var places = searchBox.getPlaces();
            var bounds = new google.maps.LatLngBounds();
            places.forEach(function (place) {
                if (place.geometry.viewport) {
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }
            });
            this.map.fitBounds(bounds);
        });


//        jQuery(this.helper.elementRef.nativeElement).find('#selected_country').on('change', (evnt, res_data) => {
//
//            this.selected_country = res_data.selected;
//            this.check_country()
//
//
//        });

        this.helper.http.post('/admin/get_all_city_list', {}).map((res_data: Response) => res_data.json()).subscribe(res_data => {
            this.city_list = res_data.city_list;


            this.city_list.forEach((city) => {
                if (city.is_use_radius) {
                    var cityCircle = new google.maps.Circle({
                        strokeColor: '#FF0000',
                        strokeOpacity: 0.8,
                        strokeWeight: 2,
                        fillColor: '#FF0000',
                        fillOpacity: 0.35,
                        map: this.map,
                        center: {lat: city.city_lat_long[0], lng: city.city_lat_long[1]},
                        radius: city.city_radius * 1000
                    });
                    google.maps.event.addListener(cityCircle, 'click', (event) => {

                        if (infoWindow) {
                            infoWindow.close();
                        }

                        infoWindow = new google.maps.InfoWindow({
                            content: city.city_name,
                            maxWidth: 320
                        });

                        infoWindow.setPosition(event.latLng);
                        infoWindow.open(this.map, cityCircle);
                    });

                } else {
                    let city_location = city.city_locations;
                    let array = [];
                    city_location.forEach((location) => {
                        array.push({lat: Number(location[1]), lng: Number(location[0])})
                    });
                    let polygon = new google.maps.Polygon({
                        map: this.map,
                        paths: array,
                        strokeColor: 'black',
                        strokeOpacity: 1,
                        strokeWeight: 1.2,
                        fillColor: 'black',
                        fillOpacity: 0.3,
                        draggable: false,
                        geodesic: true,
                        editable: false
                    });
                    google.maps.event.addListener(polygon, 'click', (event) => {

                        if (infoWindow) {
                            infoWindow.close();
                        }

                        infoWindow = new google.maps.InfoWindow({
                            content: city.city_name,
                            maxWidth: 320
                        });

                        infoWindow.setPosition(event.latLng);
                        infoWindow.open(this.map, polygon);
                    });
                }

            });

            //this.check_country();
        });
    }

//    check_country() {
//        console.log("check_country");
//        this.filtered_city_list = this.city_list.filter((city_data) => {
//            console.log(this.selected_country);
//
//            return (this.selected_country == 'All' || this.selected_country == city_data.country_id);
//        });
//    }




}
