import {Component, OnInit} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
declare var jQuery: any;
import {Helper} from "../../helper";
import * as moment from 'moment-timezone';
@Component({
    selector: 'app-order_detail',
    templateUrl: './order_detail.component.html',
    providers: [Helper]
})
export class OrderDetailComponent implements OnInit {

    order_id: Object;
    order_id_view_invoice: Object;
    order_detail: any[];
    currency_sign: any;
    public status: any;
    title: any;
    heading_title: any;
    lable_title: any;
    button: any;
    ORDER_STATE: any;
    ORDER_STATUS_ID: any;
    DATE_FORMAT: any;
    timezone: string;
    moment: any;


    order_price: number;
    total_order_price: number;
    total_store_income: number;
    total_cart_price: number;


    delivery_price: number;
    total_delivery_price: number;
    total_provider_income: number;

    promo_payment: number;
    wallet_payment: number;
    card_payment: number;

    total: number;


    // total_order_price: number;
    order_total: number;
    //total_delivery_price: number;
    //card_payment: number;
    cash_payment: number;
    product_item_total: number;
    product_item_total_array: number[];
    product_item_specification_total: number;
    product_item_specification_total_array: number[];
    product_specification_total_array: any[];
    total_item: number;

    user_first_name: String;
    user_last_name: String;
    user_email: String;
    user_phone: String;
    user_address: String;


    delivery_user_name: String;
    delivery_user_phone: String;
    delivery_user_address: String;

    user_profile: string = '';
    provider_profile: string = '';
    store_profile: string = '';

    provider_first_name: String;
    provider_last_name: String;
    provider_email: String;
    provider_phone: String;
    vehicle_name: String;

    store_name: String;
    store_email: String;
    store_address: String;
    store_phone: String;

    invoice_number: String;

    order_status: any = '';
    order_status_id: number;
    created_at: any;
    //    store_accepted_at: any;
    //    start_preparing_order_at: any;
    //    order_ready_at: any;
    //    store_order_created_at: any;
    //    accepted_at: any;
    //    cancelled_at: any;
    //    start_for_pickup_at: any;
    //    arrived_on_store_at: any;
    //    picked_order_at: any;
    //    start_for_delivery_at: any;
    //delivered_at: any;
    completed_at: any;

    order_date_time: any[] = [];
    request_date_time: any[] = [];

    is_payment_mode_cash: Boolean;
    is_user_pick_up_order: Boolean = false;
    specifications: any[] = [];
    item_note: string = '';
    hide_specification_group: any[] = [];


    constructor(public helper: Helper) {
    }

    ngOnInit() {

        this.order_id = this.helper.router_id.admin.order_id;

        this.title = this.helper.title;
        this.heading_title = this.helper.heading_title;
        this.status = this.helper.status;
        this.button = this.helper.button;

        this.lable_title = this.helper.lable_title;
        this.ORDER_STATE = this.helper.ORDER_STATE;
        this.ORDER_STATUS_ID = this.helper.ORDER_STATUS_ID;
        this.DATE_FORMAT = this.helper.DATE_FORMAT;
        this.order_total = 0;
        this.total_item = 0;
        this.product_item_total = 0;
        this.product_item_total_array = [];
        this.product_item_specification_total = 0;
        this.product_item_specification_total_array = [];
        this.product_specification_total_array = [];

        this.provider_first_name = "";
        this.provider_last_name = "";
        this.provider_email = "";
        this.vehicle_name = "";
        this.provider_phone = "";

        this.user_profile = '';
        this.provider_profile = '';
        this.store_profile = '';

        this.store_name = "";
        this.store_email = "";
        this.store_address = "";
        this.store_phone = "";

        this.user_first_name = "";
        this.user_last_name = "";
        this.user_email = "";
        this.user_phone = "";
        this.user_address = "";


        this.delivery_user_name = "";
        this.delivery_user_phone = "";
        this.delivery_user_address = "";

        this.timezone = "";
        this.moment = moment;


        this.cash_payment = 0;
        this.is_payment_mode_cash = false;
        this.order_id_view_invoice = "";



        this.order_price = 0;
        this.total_order_price = 0;
        this.total_store_income = 0;
        this.total_cart_price = 0;


        this.delivery_price = 0;
        this.total_delivery_price = 0;
        this.total_provider_income = 0;

        this.promo_payment = 0;
        this.wallet_payment = 0;
        this.card_payment = 0;

        this.total = 0;
        console.log(this.order_id);
        this.helper.http.post('/api/admin/get_order_data', {order_id: this.order_id}).map((res_data: Response) => res_data.json()).subscribe(res_data => {
            console.log(res_data.success);
            if (res_data.success == false) {

                this.helper.router.navigate(['admin/history']);

            }
            else {

                this.user_first_name = res_data.order.user_detail.first_name
                this.user_last_name = res_data.order.user_detail.last_name
                this.user_email = res_data.order.user_detail.email
                this.user_phone = res_data.order.user_detail.country_phone_code + res_data.order.user_detail.phone
                this.user_address = res_data.order.user_detail.address

                this.timezone = res_data.order.timezone;
                //this.date_time = res_data.order.date_time;
                this.order_date_time = res_data.order.date_time;
                if (res_data.order.request_detail != undefined) {
                    this.request_date_time = res_data.order.request_detail.date_time;
                }

                this.store_name = res_data.order.store_detail.name
                this.store_email = res_data.order.store_detail.email
                this.store_address = res_data.order.store_detail.address
                this.store_phone = res_data.order.store_detail.country_phone_code + res_data.order.store_detail.phone

                this.invoice_number = res_data.order.order_payment_detail.invoice_number

                this.order_status = res_data.order.order_status
                this.order_status_id = res_data.order.order_status_id
                this.is_payment_mode_cash = res_data.order.order_payment_detail.is_payment_mode_cash

                if (res_data.order.timezone != "") {
                    if (res_data.order.created_at != null) {
                        this.created_at = moment(res_data.order.created_at).tz(this.timezone).format('DD MMM YYYY HH:mm:ss');
                    }
                    if (res_data.order.completed_at != null) {
                        this.completed_at = moment(res_data.order.completed_at).tz(this.timezone).format('DD MMM YYYY HH:mm:ss');
                    }
                    //                    if (res_data.order.store_acc                    epted_at != null) {
                    //                        this.store_accepted_at = moment(res_data.order.store_accepted_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.start_preparing_                    order_at != null) {
                    //                        this.start_preparing_order_at = moment(res_data.order.start_preparing_order_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                                                                }
                    //
                    //
                    //                    if (res_data.order.order_                    ready_at != null) {
                    //                        this.order_ready_at = moment(res_data.order.order_ready_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.store_order_cr                    eated_at != null) {
                    //                        this.store_order_created_at = moment(res_data.order.store_order_created_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.acc                    epted_at != null) {
                    //                        this.accepted_at = moment(res_data.order.accepted_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.canc                    ell                    ed_at != null) {
                    //
                    //                        this.cancelled_at = moment(res_data.order.cancelled_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.start_for_p                    ick                    up_at != null) {
                    //
                    //                        this.start_for_pickup_at = moment(res_data.order.start_for_pickup_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.arrived_on_                    store_at != null) {
                    //                        this.arrived_on_store_at = moment(res_data.order.arrived_on_store_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.picked_                    order_at != null) {
                    //                        this.picked_order_at = moment(res_data.order.picked_order_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                        }
                    //                    if (res_data.order.start_for_del                    ivery_at != null) {
                    //                        this.start_for_delivery_at = moment(res_data.order.start_for_delivery_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                                                            }
                    //
                    //                    if (res_data.order.deli                    vered_at != null) {
                    //                        this.delivered_at = moment(res_data.order.delivered_at).tz(this.timezone).format('DD M                    MM YYYY HH:mm:ss');
                    //                    }


                }
                console.log(this.timezone);
                this.order_detail = res_data.order.cart_detail.order_details

                console.log(this.order_detail);
                this.currency_sign = res_data.order.country_detail.currency_sign


                this.total_cart_price = res_data.order.order_payment_detail.total_cart_price
                this.order_price = res_data.order.order_payment_detail.order_price
                this.total_order_price = res_data.order.order_payment_detail.total_order_price
                this.total_store_income = res_data.order.order_payment_detail.total_store_income


                this.delivery_price = res_data.order.order_payment_detail.delivery_price
                this.total_delivery_price = res_data.order.order_payment_detail.total_delivery_price
                this.total_provider_income = res_data.order.order_payment_detail.total_provider_income

                this.promo_payment = res_data.order.order_payment_detail.promo_payment
                this.wallet_payment = res_data.order.order_payment_detail.wallet_payment
                this.card_payment = res_data.order.order_payment_detail.card_payment

                this.total = res_data.order.order_payment_detail.total
                this.cash_payment = res_data.order.order_payment_detail.cash_payment

                this.order_id_view_invoice = res_data.order._id;

                res_data.order.cart_detail.order_details.forEach((product, product_index) => {

                    this.hide_specification_group[product_index] = "false"
                    product.items.forEach((item) => {

                        this.order_total = this.order_total + (item.item_price + item.total_specification_price) * item.quantity
                        this.product_item_total = this.product_item_total + (item.item_price + item.total_specification_price) * item.quantity
                        this.total_item = this.total_item + 1;
                        item.specifications.forEach((specification) => {
                            this.product_item_specification_total = this.product_item_specification_total + specification.specification_price;
                        })
                        this.product_item_specification_total_array.push(this.product_item_specification_total)
                        this.product_item_specification_total = 0;
                    })
                    this.product_specification_total_array.push(this.product_item_specification_total_array)
                    this.product_item_specification_total_array = [];
                    this.product_item_total_array.push(this.product_item_total)
                    this.product_item_total = 0;
                })

                if (res_data.order.cart_detail.order_details.length > 0) {
                    this.specifications = res_data.order.cart_detail.order_details[0].items[0].specifications;
                    this.item_note = res_data.order.cart_detail.order_details[0].items[0].note_for_item;
                }

                if (res_data.order.cart_detail.destination_addresses.length > 0 && res_data.order.cart_detail.destination_addresses.user_details != "") {
                    this.delivery_user_name = res_data.order.cart_detail.destination_addresses[0].user_details.name
                    this.delivery_user_phone = res_data.order.cart_detail.destination_addresses[0].user_details.country_phone_code + res_data.order.cart_detail.destination_addresses[0].user_details.phone
                    this.delivery_user_address = res_data.order.cart_detail.destination_addresses[0].address
                }



                if (res_data.order.request_detail !== undefined) {
                    if (res_data.order.provider_detail.length > 0) {
                        this.provider_first_name = res_data.order.provider_detail[0].first_name
                        this.provider_last_name = res_data.order.provider_detail[0].last_name
                        this.provider_email = res_data.order.provider_detail[0].email
                        this.provider_phone = res_data.order.provider_detail[0].country_phone_code + res_data.order.provider_detail[0].phone
                    }
                }
            }
        });

    }


    hide_specifications_group(specification_group_index) {
        this.hide_specification_group[specification_group_index] = 'true';
        jQuery('#spec_list' + specification_group_index).hide();
    }

    show_specifications_group(specification_group_index) {
        this.hide_specification_group[specification_group_index] = 'false';
        jQuery('#spec_list' + specification_group_index).show();
    }

    get_specification(product_index, item_index) {
        this.specifications = this.order_detail[product_index].items[item_index].specifications;
        this.item_note = this.order_detail[product_index].items[item_index].note_for_item;
    }

    viewOrderEarningDetail(id) {
        this.helper.router_id.admin.view_order_earning_id = id;
        this.helper.router.navigate(['admin/order_earning_detail']);

    }

    view_cart(id) {
        this.helper.router_id.admin.order_id = id;
        this.helper.router.navigate(['admin/view_cart']);
    }

}
