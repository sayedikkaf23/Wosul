import {Component, OnInit} from '@angular/core';
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Helper} from "../../helper";
declare var jQuery: any;
declare var swal: any;

export interface AddZone {

    city_id: Object,
    from_zone_id: Object,
    to_zone_id: Object,
    price: number
}

export interface AddService {

    country_id: Object,
    city_id: Object,
    vehicle_id: Object,
    delivery_service_id: Object,
    base_price_distance: Number,
    delivery_type_id: Object,

    country_name: String,
    city_name: String,
    name: String,
    vehicle_name: String,
    delivery_name: String,
    currency_sign: String,
    is_distance_unit_mile: Boolean,
    base_price: Number,
    price_per_unit_distance: Number,
    price_per_unit_time: Number,
    service_tax: Number,


    min_fare: Number,
    cancellation_fee: Number,

    surge_hours: any[],
    is_surge_hours: Boolean,
    is_business: Boolean,
    surge_multiplier: Number,
    surge_start_hour: Number,
    surge_end_hour: Number

}

@Component({
    selector: 'app-add_service',
    templateUrl: './add_service.component.html',
    providers: [Helper]
})
export class AddServiceComponent implements OnInit {

    private add_service: AddService;
    title: any;
    button: any;
    type: String;
    heading_title: any;
    validation_message: any;
    tooltip_title: any;

    country_list: any[];
    city_list: any[];
    vehicle_list: any[];
    delivery_type_list: any[];
    delivery_list: any[];
    currency_sign: String;
    is_distance_unit_mile: Boolean;
    service_id: Object;
    error: any;
    service_exist: any;

    add_surge_hours: any;
    surge_start_error: any;
    surge_end_error: any;
    myLoading: boolean = true;
    add_zone: AddZone;

    zone_price: any[] = [];

    from_zone_list: any[] = [];
    to_zone_list: any[] = [];


    constructor(private helper: Helper) {

    }

    ngAfterViewInit() {

        jQuery(".chosen-select").chosen();

        jQuery("#country").chosen();
        jQuery("#city").chosen();
        jQuery("#delivery_type_id").chosen({disable_search: true});

        setTimeout(function () {
            jQuery(".chosen-select").trigger("chosen:updated");
        }, 1000);

        jQuery('.clock-picker').clockpicker({
            'default': 'now'
        });
    }
    ngOnDestroy() {
        this.helper.router_id.admin.service_id = "";
    }

    ngOnInit() {

        this.add_zone = {
            price: null,
            city_id: null,
            to_zone_id: null,
            from_zone_id: null
        }

        // this.admin_profit_mode_on_delivery_list = ADMIN_PROFIT_ON_ORDERS

        this.add_service = {
            country_id: "",
            city_id: "",
            vehicle_id: "",
            delivery_service_id: "",
            delivery_type_id: "",
            country_name: "",
            city_name: "",
            name: "",
            vehicle_name: "",
            delivery_name: "",
            currency_sign: "",
            is_distance_unit_mile: false,
            base_price_distance: null,
            base_price: null,
            price_per_unit_distance: null,
            price_per_unit_time: null,
            service_tax: null,
            min_fare: null,
            // surge_price: null,
            cancellation_fee: null,
            // admin_profit_mode_on_delivery: null,
            // admin_profit_value_on_delivery: null,
            surge_hours: [],
            is_surge_hours: false,
            is_business: true,
            surge_multiplier: null,
            surge_start_hour: null,
            surge_end_hour: null

        }
        this.service_id = this.helper.router_id.admin.service_id;

        this.helper.http.get('/admin/get_server_country_list').map((res: Response) => res.json()).subscribe(res_data => {
            this.country_list = res_data.countries
        });


        this.helper.http.get('admin/get_delivery_type').map((res: Response) => res.json()).subscribe(res_data => {

            this.delivery_type_list = res_data.delivery_type;
        })
        this.vehicle_list = []
        this.delivery_list = []
        this.currency_sign = ""
        this.is_distance_unit_mile = false

        this.add_surge_hours = true

        jQuery(this.helper.elementRef.nativeElement).find('#country').on('change', (evnt, res_data) => {

            this.get_city_lists(res_data.selected);
            console.log("country :" + res_data.selected);

        });


        jQuery(this.helper.elementRef.nativeElement).find('#delivery_service').on('change', (evnt, res_data) => {

            this.add_service.delivery_service_id = res_data.selected;
            

        });

        jQuery(this.helper.elementRef.nativeElement).find('#city').on('change', (evnt, res_data) => {

            this.add_service.city_id = res_data.selected
            this.get_zone_list(res_data.selected);
           

        });

        jQuery(this.helper.elementRef.nativeElement).find('#vehicle').on('change', (evnt, res_data) => {

            this.add_service.vehicle_id = res_data.selected;


        });

        jQuery(this.helper.elementRef.nativeElement).find('#delivery_type_id').on('change', (evnt, res_data) => {

            this.add_service.delivery_type_id = res_data.selected


        });

        jQuery(this.helper.elementRef.nativeElement).find('#start').on('change', (evnt, res_data) => {
            this.surge_start_error = ""
            var start = jQuery("#start").val()
            this.add_service.surge_start_hour = start
            start = start.split(':');
            for (var i in this.add_service.surge_hours) {

                var surge_start = this.add_service.surge_hours[i].surge_start_hour.split(':')
                var surge_end = this.add_service.surge_hours[i].surge_end_hour.split(':')

                if (surge_start[0] > surge_end[0]) {
                    if ((start[0] > 0) && (surge_end[0] > start[0])) {
                        this.surge_start_error = "Alredy"

                    }
                    else if (surge_start[0] == start[0]) {
                        if (surge_start[1] <= start[1]) {
                            this.surge_start_error = "Alredy"
                        }
                    }
                    else if (surge_end[0] == start[0]) {
                        if (start[1] <= surge_end[1]) {
                            this.surge_start_error = "Alredy"
                        }
                    }

                }
                else {
                    if ((surge_start[0] < start[0]) && (start[0] < surge_end[0])) {
                        this.surge_start_error = "Alredy"

                    }
                    else if (surge_start[0] == start[0]) {
                        if (surge_start[1] <= start[1]) {
                            this.surge_start_error = "Alredy"
                        }
                    }
                    else if (surge_end[0] == start[0]) {
                        if (start[1] <= surge_end[1]) {
                            this.surge_start_error = "Alredy"
                        }
                    }

                }


            }

        });
        jQuery(this.helper.elementRef.nativeElement).find('#end').on('change', (evnt, res_data) => {
            this.surge_end_error = ""

            var end = jQuery("#end").val()
            var start = jQuery("#start").val()
            this.add_service.surge_end_hour = end
            end = end.split(':');
            start = start.split(':');
            for (var i in this.add_service.surge_hours) {
                var surge_start = this.add_service.surge_hours[i].surge_start_hour.split(':')
                var surge_end = this.add_service.surge_hours[i].surge_end_hour.split(':')


                if ((surge_start[0] < end[0]) && (end[0] < surge_end[0])) {
                    this.surge_end_error = "Alredy"

                }
                else if (surge_start[0] == end[0]) {
                    if (surge_start[1] <= end[1]) {
                        this.surge_end_error = "Alredy"
                    }
                }
                else if (surge_end[0] == end[0]) {
                    if (end[1] <= surge_end[1]) {
                        this.surge_end_error = "Alredy"
                    }
                }

            }


        });

        if (this.service_id == '') {
            this.type = "add";
            this.service_exist = ""
        }
        else {
            jQuery('.add').hide();
            this.type = "edit";
            this.helper.http.post('/admin/get_service_detail', {service_id: this.service_id}).map((res_data: Response) => res_data.json()).subscribe(res_data => {

                if (res_data.success == false) {

                    this.helper.router.navigate(['admin/service']);

                }
                else {

                    this.add_service.country_id = res_data.service.country_id;
                    this.add_service.city_id = res_data.service.city_id;

                    this.add_zone.city_id = res_data.service.city_id;

                    this.zone_price = res_data.zone_price;

                    this.from_zone_list = res_data.city_zone;
                    this.to_zone_list = res_data.city_zone;

                    setTimeout(function () {
                        jQuery("#from_zone_id").trigger("chosen:updated");
                        jQuery("#to_zone_id").trigger("chosen:updated");
                    }, 1000);
                    // this.add_service.vehicle_id = res_data.service.vehicle_id;
                    // this.add_service.delivery_service_id = res_data.service.delivery_service_id;
                    //this.add_service.delivery_type_id = res_data.service.delivery_type_id;

                    this.add_service.country_name = res_data.service.country_details.country_name;
                    this.add_service.city_name = res_data.service.city_details.city_name;
                    //this.add_service.name = res_data.service.delivery_type_details.name;

                    // this.add_service.vehicle_name = res_data.service.vehicle_details.vehicle_name;
                    // this.add_service.delivery_name = res_data.service.delivery_details.delivery_name;
                    this.add_service.base_price_distance = res_data.service.base_price_distance;
                    this.add_service.base_price = res_data.service.base_price;
                    this.add_service.price_per_unit_distance = res_data.service.price_per_unit_distance;

                    this.add_service.price_per_unit_time = res_data.service.price_per_unit_time;
                    this.add_service.service_tax = res_data.service.service_tax;
                    this.add_service.min_fare = res_data.service.min_fare;

                    this.currency_sign = res_data.service.country_details.currency_sign;
                    this.is_distance_unit_mile = res_data.service.country_details.is_distance_unit_mile;



                    //this.add_service.surge_price = res_data.service.surge_price;
                    this.add_service.cancellation_fee = res_data.service.cancellation_fee;
                    // this.add_service.admin_profit_mode_on_delivery = res_data.service.admin_profit_mode_on_delivery;
                    // this.add_service.admin_profit_value_on_delivery = res_data.service.admin_profit_value_on_delivery;

                    this.add_service.surge_hours = res_data.service.surge_hours;
                    this.add_service.is_surge_hours = res_data.service.is_surge_hours;
                    this.add_service.is_business = res_data.service.is_business;
                    this.add_service.surge_multiplier = res_data.service.surge_multiplier;
                    this.add_service.surge_start_hour = res_data.service.surge_start_hour;
                    this.add_service.surge_end_hour = res_data.service.surge_end_hour;



                }
            });

        }

        jQuery(this.helper.elementRef.nativeElement).find('#from_zone_id').on('change', (evnt, res_data) => {
            this.add_zone.from_zone_id = res_data.selected;
        });
        jQuery(this.helper.elementRef.nativeElement).find('#to_zone_id').on('change', (evnt, res_data) => {
            this.add_zone.to_zone_id = res_data.selected;
        });

        this.title = this.helper.title;
        this.button = this.helper.button;
        this.heading_title = this.helper.heading_title;
        this.tooltip_title = this.helper.tooltip_title;

        this.validation_message = this.helper.validation_message;
    }

    get_zone_list(city_id) {
        this.helper.http.post('/admin/get_zone_detail', {city_id: city_id}).map((res_data: Response) => res_data.json()).subscribe(res_data => {

            if (res_data.success) {
                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
                this.from_zone_list = res_data.city_zone;
                this.to_zone_list = res_data.city_zone;
                
                console.log(this.from_zone_list);
                console.log(this.to_zone_list);

                setTimeout(function () {
                    jQuery("#from_zone_id").trigger("chosen:updated");
                    jQuery("#to_zone_id").trigger("chosen:updated");
                }, 1000);

            } else {
                this.helper.data.storage = {
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
            }
        });

    }


    add_surge_hours_array() {
        this.add_surge_hours = false
        this.add_service.surge_hours.push({surge_multiplier: Number(this.add_service.surge_multiplier), surge_start_hour: this.add_service.surge_start_hour, surge_end_hour: this.add_service.surge_end_hour});
        this.add_service.surge_multiplier = null
        this.add_service.surge_start_hour = null
        this.add_service.surge_end_hour = null
    }
    add_zone_price() {
        this.add_zone.city_id = this.add_service.city_id;
        this.helper.http.post('/admin/add_zone_price', this.add_zone).map((res_data: Response) => res_data.json()).subscribe(res_data => {

            if (res_data.success) {

                var from_index = this.from_zone_list.findIndex((x) => x._id == this.add_zone.from_zone_id);
                var to_index = this.to_zone_list.findIndex((x) => x._id == this.add_zone.to_zone_id);

                var json = res_data.zone_value;
                json.from_zone_detail = {
                    title: this.from_zone_list[from_index].title
                }
                json.to_zone_detail = {
                    title: this.to_zone_list[to_index].title
                }
                this.zone_price.push(json);
                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
                this.helper.message();
            } else {
                this.helper.data.storage = {
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
                this.helper.message();
            }
        });
    }
    update_zone_price(data) {
        var json = {
            _id: data._id,
            price: Number(data.price)
        }
        this.helper.http.post('/admin/update_zone_price', json).map((res_data: Response) => res_data.json()).subscribe(res_data => {

            if (res_data.success) {
                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
            } else {
                this.helper.data.storage = {
                    "message": this.helper.ERROR_CODE[res_data.error_code],
                    "class": "alert-danger"
                }
            }
        });
    }



    remove_surge_data(surge_data) {
        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(() => {
            var i = this.add_service.surge_hours.indexOf(surge_data);
            if (i != -1) {
                this.add_service.surge_hours.splice(i, 1);
            }
            swal(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            );
        }).catch(swal.noop)
    }
    
  


    get_city_lists(countryid) {
        this.add_service.country_id = countryid
        this.helper.http.post('/api/admin/get_city_lists', {country_id: countryid}).map((res: Response) => res.json()).subscribe(res_data => {

            var city_list = res_data.cities;
            this.currency_sign = res_data.currency_sign
            this.is_distance_unit_mile = res_data.is_distance_unit_mile

            var services_list = res_data.services;
            var city_array = [];
            var service_array = [];
            var unique_array = [];
            for (var index in city_list) {
                city_array.push({_id: city_list[index]._id, name: city_list[index].city_name});
            }
            for (var index in services_list) {
                service_array.push({_id: services_list[index].city_detail._id, name: services_list[index].city_detail.city_name});
            }
            unique_array = city_array.filter(function (current) {
                return service_array.filter(function (current_b) {
                    return current_b['_id'] == current['_id']
                }).length == 0
            });
            this.city_list = unique_array;
            this.add_service.city_id = unique_array[0]._id;
          


        });
        setTimeout(function () {
            jQuery("#city").trigger("chosen:updated");
        }, 1000);

    }


    get_vehicle_list(cityid) {
        this.add_service.city_id = cityid
        this.helper.http.post('/api/admin/get_vehicle_list', {city_id: cityid}).map((res: Response) => res.json()).subscribe(res_data => {

            var vehicles_list = res_data.vehicles;
            var services_list = res_data.services;
            var vehicle_array = [];
            var service_array = [];
            var unique_array = [];
            for (var index in vehicles_list) {
                vehicle_array.push({_id: vehicles_list[index]._id, name: vehicles_list[index].vehicle_name});
            }
            for (var index in services_list) {
                service_array.push({_id: services_list[index].vehicle_detail._id, name: services_list[index].vehicle_detail.vehicle_name});
            }
            unique_array = vehicle_array.filter(function (current) {
                return service_array.filter(function (current_b) {
                    return current_b['_id'] == current['_id']
                }).length == 0
            });
            this.vehicle_list = unique_array

        });
        setTimeout(function () {
            jQuery("#vehicle").trigger("chosen:updated");
        }, 1000);

    }



    get_delivery_list(cityid) {
        this.add_service.city_id = cityid
        this.helper.http.post('/api/admin/get_delivery_list_for_city', {city_id: cityid}).map((res: Response) => res.json()).subscribe(res_data => {

            this.delivery_list = res_data.deliveries
        });
        setTimeout(function () {
            jQuery("#delivery_service").trigger("chosen:updated");
        }, 1000);
    }

    addService(servicedata) {

        if (this.type == 'add') {
            this.myLoading = true;
            this.helper.http.post('/admin/add_service_data', servicedata).map((res: Response) => res.json()).subscribe(res_data => {
                this.myLoading = false;
                if (res_data.success == true) {
                    this.helper.data.storage = {
                        "message": this.helper.MESSAGE_CODE[res_data.message],
                        "class": "alert-info"
                    }
                    this.helper.router.navigate(['admin/service']);
                }
                else {
                    this.helper.data.storage = {
                        "message": this.helper.ERROR_CODE[res_data.error_code],
                        "class": "alert-danger"
                    }
                }

            },
                (error: any) => {
                    this.myLoading = false;
                    this.helper.http_status(error)
                });
        } else {

            this.updateService(servicedata)
        }
    }

    updateService(service_data) {
        this.myLoading = true;
        this.helper.http.post('/admin/update_service', service_data).map((res: Response) => res.json()).subscribe(res_data => {
            this.myLoading = false;
            if (res_data.success == true) {

                this.helper.data.storage = {
                    "message": this.helper.MESSAGE_CODE[res_data.message],
                    "class": "alert-info"
                }
                this.helper.router.navigate(['admin/service']);


            }
            else {

                this.helper.router.navigate(['admin/service']);

            }
        },
            (error: any) => {
                this.myLoading = false;
                this.helper.http_status(error)
            });
    }

}
