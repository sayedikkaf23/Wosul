import { Component } from '@angular/core';

declare var jQuery:any;

@Component({
    selector: 'admin_basic',
    templateUrl: 'admin_basic.template.html'
})
export class admin_basicComponent {}